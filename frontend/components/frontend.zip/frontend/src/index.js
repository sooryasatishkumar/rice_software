import React, { useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import '../src/styles/index.css';
import App from './App.js';
import reportWebVitals from './reportWebVitals';
import './styles/main.css'; // remove if unused

const Root = () => {
  useEffect(() => {
    // 🚫 Prevent scroll from changing number inputs
    const preventScroll = (e) => {
      if (e.target.type === "number") {
        e.preventDefault();
      }
    };
    document.addEventListener("wheel", preventScroll, { passive: false });

    // ⌨️ Enter behaves like Tab, with custom select handling
    const handleEnterAsTab = (e) => {
      if (e.key === "Enter" && e.target.tagName !== "TEXTAREA") {
        const form = e.target.form;
        if (!form) return;

        e.preventDefault();

        if (e.target.tagName === "SELECT") {
          // First Enter → expand options
          if (!e.target.dataset.open) {
            e.target.size = e.target.options.length;
            e.target.dataset.open = "true";
            return;
          } else {
            // Second Enter → collapse and move to next field
            e.target.size = 0;
            e.target.removeAttribute("data-open");
          }
        }

        // Move to next element
        const index = Array.prototype.indexOf.call(form, e.target);
        const next = form.elements[index + 1];
        if (next) {
          next.focus();
        }
      }
    };
    document.addEventListener("keydown", handleEnterAsTab);

    return () => {
      document.removeEventListener("wheel", preventScroll);
      document.removeEventListener("keydown", handleEnterAsTab);
    };
  }, []);

  return <App />;
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>
);

reportWebVitals();
