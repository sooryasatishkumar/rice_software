import React from 'react';
import './PrintableGodownReport.css'; // Ensure this file exists with your styles

// Helper function to format numbers
const formatNumber = (value) => {
  const num = parseFloat(value);
  if (isNaN(num) || num === 0) {
    return ''; // Return empty string if value is zero or invalid
  }
  return num.toFixed(3);
};

const PrintableGodownReport = ({ data, viewType }) => {
  // data: Array of grouped data entries
  // viewType: 'paddy' or 'rice'

  // Initialize grand totals
  const grandTotals = {
    gradeA: 0,
    gradeC: 0,
    total: 0,
  };

  return (
    <div className="printable-godown-report">
      {data.map((monthData, monthIndex) => {
        // Calculate totals for the month
        const monthTotals = monthData.godowns.reduce(
          (totals, godownData) => {
            totals.gradeA += godownData.gradeA;
            totals.gradeC += godownData.gradeC;
            totals.total += godownData.total;
            return totals;
          },
          { gradeA: 0, gradeC: 0, total: 0 }
        );

        // Update grand totals
        grandTotals.gradeA += monthTotals.gradeA;
        grandTotals.gradeC += monthTotals.gradeC;
        grandTotals.total += monthTotals.total;

        return (
          <div key={monthIndex} style={{ marginBottom: '40px' }}>
            <h2 style={{ textAlign: 'center' }}>{monthData.month}</h2>
            <table className="styled-table">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Name of the Godown</th>
                  <th>A Grade</th>
                  <th>C Grade</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                {monthData.godowns.map((godownData, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{godownData.godown}</td>
                    <td>{formatNumber(godownData.gradeA)}</td>
                    <td>{formatNumber(godownData.gradeC)}</td>
                    <td>{formatNumber(godownData.total)}</td>
                  </tr>
                ))}
                {/* Monthly Total Row */}
                <tr>
                  <td colSpan="2">
                    <strong>Monthly Total</strong>
                  </td>
                  <td>
                    <strong>{formatNumber(monthTotals.gradeA)}</strong>
                  </td>
                  <td>
                    <strong>{formatNumber(monthTotals.gradeC)}</strong>
                  </td>
                  <td>
                    <strong>{formatNumber(monthTotals.total)}</strong>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      })}
      {/* Grand Totals */}
      <div>
        <h2 style={{ textAlign: 'center' }}>Grand Totals</h2>
        <table className="styled-table">
          <thead>
            <tr>
              <th>A Grade</th>
              <th>C Grade</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{formatNumber(grandTotals.gradeA)}</td>
              <td>{formatNumber(grandTotals.gradeC)}</td>
              <td>{formatNumber(grandTotals.total)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PrintableGodownReport;
