import React, { useMemo } from 'react';

const PrintableRice = ({
  data,
  gradeFilter,
  fromMonth,
  toMonth,
  summaryView,
  printBill,
}) => {
  // Function to format numbers to three decimal places
  const formatNumber = (value) => {
    const num = parseFloat(value);
    if (!num || num === 0) {
      return ''; // Return empty string if value is zero or falsy
    }
    return num.toFixed(3);
  };

  // Function to format integer numbers
  const formatInteger = (value) => {
    const num = parseInt(value, 10);
    if (!num || num === 0) {
      return ''; // Return empty string if value is zero or falsy
    }
    return num;
  };

  // Function to format dates
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    if (isNaN(date)) return 'Invalid Date';
    const options = {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Asia/Kolkata',
    };
    return new Intl.DateTimeFormat('en-GB', options).format(date);
  };

  // Filter and sort data based on gradeFilter and date range
  const filteredData = useMemo(() => {
    let result = data;

    if (gradeFilter) {
      result = result.filter(
        (entry) =>
          entry.variety &&
          entry.variety.toLowerCase() === gradeFilter.toLowerCase()
      );
    }

    if (fromMonth && toMonth) {
      const fromDate = new Date(fromMonth);
      const toDate = new Date(toMonth);
      result = result.filter((entry) => {
        const entryDate = new Date(entry.date);
        return entryDate >= fromDate && entryDate <= toDate;
      });
    }

    // Sort the filtered data by date in ascending order
    result = result.sort((a, b) => new Date(a.date) - new Date(b.date));

    return result;
  }, [data, gradeFilter, fromMonth, toMonth]);

  // Group data by month
  const groupedData = useMemo(() => {
    const groups = {};
    filteredData.forEach((entry) => {
      const date = new Date(entry.date);
      const month = date.toLocaleString('default', {
        month: 'long',
        year: 'numeric',
      });
      if (!groups[month]) {
        groups[month] = [];
      }
      groups[month].push(entry);
    });

    // To ensure the months are ordered chronologically, extract and sort the keys
    const sortedMonths = Object.keys(groups).sort((a, b) => {
      const dateA = new Date(a);
      const dateB = new Date(b);
      return dateA - dateB;
    });

    // Create a new object with sorted month keys
    const sortedGroups = {};
    sortedMonths.forEach((month) => {
      sortedGroups[month] = groups[month];
    });

    return sortedGroups;
  }, [filteredData]);

  // Function to calculate totals for a set of entries
  const calculateTotals = (entries) => {
    return entries.reduce(
      (totals, entry) => {
        const onbBags = parseInt(entry.onbBags, 10) || 0;
        const ssBags = parseInt(entry.ssBags, 10) || 0;
        const swpBags = parseInt(entry.swpBags, 10) || 0;
        const totalBags = onbBags + ssBags + swpBags;

        // Include FRK weight if not printBill
        const frkWeight = !printBill ? parseFloat(entry.frk) || 0 : 0;

        const tonsKgs = parseFloat(entry.tonsKgs) || 0;
        const totalWeight = tonsKgs + frkWeight; // Add FRK weight if applicable

        if (entry.variety === 'BRA') {
          totals.totalBagsA += totalBags;
          totals.totalWeightsA += totalWeight;
        } else if (entry.variety === 'BRC') {
          totals.totalBagsC += totalBags;
          totals.totalWeightsC += totalWeight;
        }

        totals.onbBags += onbBags;
        totals.ssBags += ssBags;
        totals.swpBags += swpBags;

        return totals;
      },
      {
        totalBagsA: 0,
        totalWeightsA: 0,
        totalBagsC: 0,
        totalWeightsC: 0,
        onbBags: 0,
        ssBags: 0,
        swpBags: 0,
      }
    );
  };

  // Calculate overall totals
  const overallTotals = calculateTotals(filteredData);

  // Initialize row index for continuous numbering
  let rowIndex = 1;

  return (
    <div>
      <h2>
        Rice Entries {gradeFilter ? `(Grade ${gradeFilter.toUpperCase()})` : ''}
      </h2>

      <table>
        <thead>
          <tr>
            <th rowSpan="2">No</th>
            <th rowSpan="2">AD Date</th>
            <th rowSpan="2">Godown</th>
            <th rowSpan="2">Variety</th>
            <th colSpan="2">A</th>
            <th colSpan="2">C</th>
            <th rowSpan="2">AD No</th>
            <th colSpan="3">Gunny Type</th>
            {printBill && (
              <>
                <th rowSpan="2" style={{ width: '100px', padding: '10px' }}>QC No</th>
                <th rowSpan="2" style={{ width: '50px', padding: '5px' }}>Moisture</th>
              </>
            )}
          </tr>
          <tr>
            <th>Bags</th>
            <th>Weights</th>
            <th>Bags</th>
            <th>Weights</th>
            <th>ONB</th>
            <th>SS</th>
            <th>SWP</th>
          </tr>
        </thead>
        <tbody>
          {Object.keys(groupedData).length === 0 ? (
            <tr>
              <td colSpan={printBill ? 14 : 12}>No data available</td>
            </tr>
          ) : (
            Object.keys(groupedData).map((month) => {
              const monthEntries = groupedData[month];
              const monthTotals = calculateTotals(monthEntries);

              return (
                <React.Fragment key={month}>
                  {/* Month Header */}
                  {summaryView && (
                    <tr>
                      <td colSpan={printBill ? 14 : 12}>
                        <strong>{month}</strong>
                      </td>
                    </tr>
                  )}
                  {/* Entries for the month */}
                  {monthEntries.map((entry) => {
                    const onbBags = parseInt(entry.onbBags, 10) || 0;
                    const ssBags = parseInt(entry.ssBags, 10) || 0;
                    const swpBags = parseInt(entry.swpBags, 10) || 0;
                    const totalBags = onbBags + ssBags + swpBags;

                    // Include FRK weight if not printBill
                    const frkWeight = !printBill ? parseFloat(entry.frk) || 0 : 0;

                    const tonsKgs = parseFloat(entry.tonsKgs) || 0;
                    const totalWeight = tonsKgs + frkWeight; // Add FRK weight if applicable

                    return (
                      <tr key={entry.id}>
                        <td>{rowIndex++}</td>
                        <td>
  {(() => {
    const raw = entry.adDate || entry.date || ''; // fallback if adDate missing

    // Handle already-Date object
    if (raw instanceof Date && !isNaN(raw)) {
      return raw.toLocaleDateString('en-GB');
    }

    // Handle numbers (epoch in seconds or ms)
    if (typeof raw === 'number') {
      const ms = raw < 1e12 ? raw * 1000 : raw;
      const d = new Date(ms);
      return isNaN(d) ? '' : d.toLocaleDateString('en-GB');
    }

    // Handle strings
    if (typeof raw === 'string') {
      const s = raw.trim();

      // Try ISO or YYYY-MM-DD first
      if (/\d{4}-\d{2}-\d{2}/.test(s) || s.includes('T')) {
        const d = new Date(s);
        if (!isNaN(d)) return d.toLocaleDateString('en-GB');
      }

      // Try DD/MM/YYYY
      if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(s)) {
        const [dd, mm, yyyy] = s.split('/');
        const d = new Date(`${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`);
        if (!isNaN(d)) return d.toLocaleDateString('en-GB');
      }

      // Try numeric-like string
      const num = Number(s);
      if (!isNaN(num)) {
        const ms = num < 1e12 ? num * 1000 : num;
        const d = new Date(ms);
        if (!isNaN(d)) return d.toLocaleDateString('en-GB');
      }

      // Fallback — show original text if nothing parsed
      return s;
    }

    // Fallback empty
    return '';
  })()}
</td>

                        <td>{entry.godown || ''}</td>
                        <td>{entry.variety || ''}</td>
                        {/* A Grade Columns */}
                        <td>{entry.variety === 'BRA' ? formatInteger(totalBags) : ''}</td>
                        <td>{entry.variety === 'BRA' ? formatNumber(totalWeight) : ''}</td>
                        {/* C Grade Columns */}
                        <td>{entry.variety === 'BRC' ? formatInteger(totalBags) : ''}</td>
                        <td>{entry.variety === 'BRC' ? formatNumber(totalWeight) : ''}</td>
                        <td>{entry.adNumber || ''}</td>
                        {/* Gunny Types */}
                        <td>{formatInteger(onbBags)}</td>
                        <td>{formatInteger(ssBags)}</td>
                        <td>{formatInteger(swpBags)}</td>
                        {printBill && (
                          <>
                            <td style={{ width: '100px', padding: '10px', textAlign: 'center' }}>
                              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </td> {/* QC No, with spaces for 6 characters */}
                            <td style={{ width: '50px', padding: '5px', textAlign: 'center' }}>
                              {entry.moisture || ''}
                            </td> {/* Moisture */}
                          </>
                        )}
                      </tr>
                    );
                  })}
                  {/* Totals for the month */}
                  <tr>
                    <td colSpan="4">
                      <strong>Totals for {month}</strong>
                    </td>
                    <td>
                      <strong>{formatInteger(monthTotals.totalBagsA)}</strong>
                    </td>
                    <td>
                      <strong>{formatNumber(monthTotals.totalWeightsA)}</strong>
                    </td>
                    <td>
                      <strong>{formatInteger(monthTotals.totalBagsC)}</strong>
                    </td>
                    <td>
                      <strong>{formatNumber(monthTotals.totalWeightsC)}</strong>
                    </td>
                    <td></td>
                    <td>
                      <strong>{formatInteger(monthTotals.onbBags)}</strong>
                    </td>
                    <td>
                      <strong>{formatInteger(monthTotals.ssBags)}</strong>
                    </td>
                    <td>
                      <strong>{formatInteger(monthTotals.swpBags)}</strong>
                    </td>
                    {printBill && (
                      <>
                        <td style={{ width: '100px', padding: '10px', textAlign: 'center' }}>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </td> {/* QC No, blank with 6 character space */}
                        <td style={{ width: '25px', padding: '5px', textAlign: 'center' }}></td> {/* Moisture */}
                      </>
                    )}
                  </tr>
                </React.Fragment>
              );
            })
          )}
          {/* Overall Totals */}
          <tr>
            <td colSpan="4">
              <strong>Overall Totals</strong>
            </td>
            <td>
              <strong>{formatInteger(overallTotals.totalBagsA)}</strong>
            </td>
            <td>
              <strong>{formatNumber(overallTotals.totalWeightsA)}</strong>
            </td>
            <td>
              <strong>{formatInteger(overallTotals.totalBagsC)}</strong>
            </td>
            <td>
              <strong>{formatNumber(overallTotals.totalWeightsC)}</strong>
            </td>
            <td></td>
            <td>
              <strong>{formatInteger(overallTotals.onbBags)}</strong>
            </td>
            <td>
              <strong>{formatInteger(overallTotals.ssBags)}</strong>
            </td>
            <td>
              <strong>{formatInteger(overallTotals.swpBags)}</strong>
            </td>
            {printBill && (
              <>
                <td style={{ width: '100px', padding: '10px', textAlign: 'center' }}>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </td> {/* QC No, blank with 6 character space */}
                <td style={{ width: '20px', padding: '5px', textAlign: 'center' }}></td> {/* Moisture */}
              </>
            )}
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default PrintableRice;
