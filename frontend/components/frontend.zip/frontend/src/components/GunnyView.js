// src/components/GunnyView.js

import React from 'react';
import '../styles/Table.css';

const GunnyView = ({ paddyData, riceData, groupDataByMonth }) => {
  // 1. Helper function to format "dd/mm/yyyy" to "Month Year" (e.g., "July 2024")
  const formatMonthYear = (dateString) => {
    if (!dateString) return '';

    // Split the date string into day, month, and year
    const [day, month, year] = dateString.split('/').map(Number);

    // Validate the extracted parts
    if (
      !day || !month || !year ||
      day < 1 || day > 31 ||
      month < 1 || month > 12 ||
      year < 1000 || year > 9999
    ) {
      return 'Invalid Date';
    }

    // Create a Date object (months are 0-indexed in JavaScript)
    const date = new Date(year, month - 1, day);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
      return 'Invalid Date';
    }

    // Format to "Month Year" (e.g., "July 2024")
    return date.toLocaleString('default', { month: 'long', year: 'numeric' });
  };

  // 2. Helper function to sort grouped data by month and year
  const sortGroupedData = (groupedData) => {
    return [...groupedData].sort((a, b) => {
      // a.month and b.month are in "dd/mm/yyyy" format
      const [aDay, aMonth, aYear] = a.month.split('/').map(Number);
      const [bDay, bMonth, bYear] = b.month.split('/').map(Number);
      
      if (aYear !== bYear) {
        return aYear - bYear; // Sort by year ascending
      }
      return aMonth - bMonth; // Sort by month ascending
    });
  };

  // 3. Group data by month using the provided function
  const groupedPaddy = groupDataByMonth(paddyData);
  const groupedRice = groupDataByMonth(riceData);

  // 4. Sort the grouped data chronologically
  const sortedGroupedPaddy = sortGroupedData(groupedPaddy);
  const sortedGroupedRice = sortGroupedData(groupedRice);

  // 5. Calculate Totals for Paddy
  const paddyTotals = {
    nbBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.nbBags, 0),
    onbBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.onbBags, 0),
    ssBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.ssBags, 0),
    swpBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.swpBags, 0),
    totalBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.totalBags, 0),
  };

  // 6. Calculate Totals for Rice
  const riceTotals = {
    nbBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.nbBags, 0),
    onbBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.onbBags, 0),
    ssBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.ssBags, 0),
    swpBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.swpBags, 0),
    totalBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.totalBags, 0),
  };

  // 7. Shifted Paddy Issue Gunny (each category moved one position)
  const shiftedPaddyIssue = {
    nbBags: 0, // NB shifted to ONB
    onbBags: paddyTotals.nbBags, // NB shifted to ONB
    ssBags: paddyTotals.onbBags, // ONB shifted to SS
    swpBags: paddyTotals.ssBags, // SS shifted to SWP
  };
  shiftedPaddyIssue.totalBags = shiftedPaddyIssue.nbBags + shiftedPaddyIssue.onbBags + shiftedPaddyIssue.ssBags + shiftedPaddyIssue.swpBags;

  // 8. Excess = Rice Deposits Gunny - Paddy Issue Gunny (first row)
  const excess = {
    nbBags: riceTotals.nbBags - paddyTotals.nbBags,
    onbBags: riceTotals.onbBags - paddyTotals.onbBags,
    ssBags: riceTotals.ssBags - paddyTotals.ssBags,
    swpBags: riceTotals.swpBags - paddyTotals.swpBags,
  };
  excess.totalBags = excess.nbBags + excess.onbBags + excess.ssBags + excess.swpBags;

  // 9. Balance Gunny to be Deposited = Shifted Paddy Issue Gunny - Rice Deposits Gunny
  const balanceToBeDeposited = {
    nbBags: shiftedPaddyIssue.nbBags - riceTotals.nbBags,
    onbBags: shiftedPaddyIssue.onbBags - riceTotals.onbBags,
    ssBags: shiftedPaddyIssue.ssBags - riceTotals.ssBags,
    swpBags: shiftedPaddyIssue.swpBags - riceTotals.swpBags,
  };
  balanceToBeDeposited.totalBags = balanceToBeDeposited.nbBags + balanceToBeDeposited.onbBags + balanceToBeDeposited.ssBags + balanceToBeDeposited.swpBags;

  return (
    <div>
      {/* Paddy Gunny Receipt */}
      <h3>Paddy Gunny Receipt</h3>
      <table className="styled-table">
        <thead>
          <tr>
            <th>Month</th>
            <th>NB</th>
            <th>ONB</th>
            <th>SS</th>
            <th>SWP</th>
            <th>Total Bags</th>
            <th>Tons/Kgs</th>
          </tr>
        </thead>
        <tbody>
          {sortedGroupedPaddy.map((entry, index) => (
            <tr key={index}>
              <td>{formatMonthYear(entry.month)}</td>
              <td>{entry.nbBags}</td>
              <td>{entry.onbBags}</td>
              <td>{entry.ssBags}</td>
              <td>{entry.swpBags}</td>
              <td>{entry.totalBags}</td>
              <td>{entry.tonsKgs}</td>
            </tr>
          ))}
          {/* Grand Totals for Paddy */}
          <tr>
            <th>Total</th>
            <th>{paddyTotals.nbBags}</th>
            <th>{paddyTotals.onbBags}</th>
            <th>{paddyTotals.ssBags}</th>
            <th>{paddyTotals.swpBags}</th>
            <th>{paddyTotals.totalBags}</th>
            <th>{sortedGroupedPaddy.reduce((sum, entry) => sum + parseFloat(entry.tonsKgs), 0).toFixed(3)}</th>
          </tr>
        </tbody>
      </table>

      {/* Rice Gunny Deposit */}
      <h3>Rice Gunny Deposit</h3>
      <table className="styled-table">
        <thead>
          <tr>
            <th>Month</th>
            <th>NB</th>
            <th>ONB</th>
            <th>SS</th>
            <th>SWP</th>
            <th>Total Bags</th>
            <th>Tons/Kgs</th>
          </tr>
        </thead>
        <tbody>
          {sortedGroupedRice.map((entry, index) => (
            <tr key={index}>
              <td>{formatMonthYear(entry.month)}</td>
              <td>{entry.nbBags}</td>
              <td>{entry.onbBags}</td>
              <td>{entry.ssBags}</td>
              <td>{entry.swpBags}</td>
              <td>{entry.totalBags}</td>
              <td>{entry.tonsKgs}</td>
            </tr>
          ))}
          {/* Grand Totals for Rice */}
          <tr>
            <th>Total</th>
            <th>{riceTotals.nbBags}</th>
            <th>{riceTotals.onbBags}</th>
            <th>{riceTotals.ssBags}</th>
            <th>{riceTotals.swpBags}</th>
            <th>{riceTotals.totalBags}</th>
            <th>{sortedGroupedRice.reduce((sum, entry) => sum + parseFloat(entry.tonsKgs), 0).toFixed(3)}</th>
          </tr>
        </tbody>
      </table>

      {/* Due Gunny Accounts */}
      <h3>Due Gunny Accounts</h3>
      <table className="styled-table">
        <thead>
          <tr>
            <th></th>
            <th>NB</th>
            <th>ONB</th>
            <th>SS</th>
            <th>SWP</th>
            <th>Total Bags</th>
          </tr>
        </thead>
        <tbody>
          {/* Paddy Issue Gunny */}
          <tr>
            <td>Paddy Issue Gunny</td>
            <td>{paddyTotals.nbBags}</td>
            <td>{paddyTotals.onbBags}</td>
            <td>{paddyTotals.ssBags}</td>
            <td>{paddyTotals.swpBags}</td>
            <td>{paddyTotals.totalBags}</td>
          </tr>
          {/* Shifted Paddy Issue Gunny */}
          <tr>
            <td>Paddy Issue Gunny Shifted</td>
            <td>{shiftedPaddyIssue.nbBags}</td>
            <td>{shiftedPaddyIssue.onbBags}</td>
            <td>{shiftedPaddyIssue.ssBags}</td>
            <td>{shiftedPaddyIssue.swpBags}</td>
            <td>{shiftedPaddyIssue.totalBags}</td>
          </tr>
          {/* Rice Deposits Gunny */}
          <tr>
            <td>Rice Deposits Gunny</td>
            <td>{riceTotals.nbBags}</td>
            <td>{riceTotals.onbBags}</td>
            <td>{riceTotals.ssBags}</td>
            <td>{riceTotals.swpBags}</td>
            <td>{riceTotals.totalBags}</td>
          </tr>
          {/* Excess */}
          <tr>
            <td>Excess</td>
            <td>{excess.nbBags}</td>
            <td>{excess.onbBags}</td>
            <td>{excess.ssBags}</td>
            <td>{excess.swpBags}</td>
            <td>{excess.totalBags}</td>
          </tr>
          {/* Balance Gunny to be Deposited */}
          <tr>
            <td>Balance Gunny to be Deposited</td>
            <td>{balanceToBeDeposited.nbBags}</td>
            <td>{balanceToBeDeposited.onbBags}</td>
            <td>{balanceToBeDeposited.ssBags}</td>
            <td>{balanceToBeDeposited.swpBags}</td>
            <td>{balanceToBeDeposited.totalBags}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default GunnyView;
