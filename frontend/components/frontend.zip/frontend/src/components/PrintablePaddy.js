import React from 'react';

const PrintablePaddy = ({ data, summaryView, fromMonth, toMonth }) => {
  // Function to format numbers to three decimal places
  const formatNumber = (value) => {
    const num = parseFloat(value);
    if (!num || num === 0) {
      return ''; // Return empty string if value is zero or falsy
    }
    return num.toFixed(3);
  };

  // Function to format integer numbers
  const formatInteger = (value) => {
    const num = parseInt(value);
    if (!num || num === 0) {
      return ''; // Return empty string if value is zero or falsy
    }
    return num;
  };

  // Function to calculate totals for given entries
  const calculateTotals = (entries) => {
    return entries.reduce(
      (totals, entry) => {
        const nbBags = parseInt(entry.nbBags) || 0;
        const onbBags = parseInt(entry.onbBags) || 0;
        const ssBags = parseInt(entry.ssBags) || 0;
        const totalBags = nbBags + onbBags + ssBags;
        const tonsKgs = parseFloat(entry.tonsKgs) || 0;

        totals.nbBags += nbBags;
        totals.onbBags += onbBags;
        totals.ssBags += ssBags;

        if (entry.grade === 'RPA') {
          totals.totalBagsA += totalBags;
          totals.totalWeightsA += tonsKgs;
        } else if (entry.grade === 'RPC') {
          totals.totalBagsC += totalBags;
          totals.totalWeightsC += tonsKgs;
        }
        return totals;
      },
      { totalBagsA: 0, totalWeightsA: 0, totalBagsC: 0, totalWeightsC: 0, nbBags: 0, onbBags: 0, ssBags: 0 }
    );
  };

  // Function to group data by date
  const groupDataByDate = (entries) => {
    return entries.reduce((acc, entry) => {
      const date = new Date(entry.date).toLocaleDateString('en-GB');
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(entry);
      return acc;
    }, {});
  };

  const groupedData = groupDataByDate(data);

  // Calculate overall totals
  const totals = calculateTotals(data);

  // Initialize row index for continuous numbering
  let rowIndex = 1;

  // Detailed view rendering
  return (
    <div className="printable-paddy-container">
      <h2>Paddy Entries</h2>
      <table className="paddy-table">
        <thead>
          <tr>
            <th rowSpan="2">No</th>
            <th rowSpan="2">Date</th>
            <th rowSpan="2">Godown</th>
            <th rowSpan="2">Issue Memo No.</th>
            <th rowSpan="2">Variety</th>
            <th colSpan="2">A</th>
            <th colSpan="2">C</th>
            <th colSpan="3">Gunny Type</th>
          </tr>
          <tr>
            <th>Bags</th>
            <th>Weights</th>
            <th>Bags</th>
            <th>Weights</th>
            <th>NB</th>
            <th>ONB</th>
            <th>SS</th>
          </tr>
        </thead>
        <tbody>
          {Object.keys(groupedData)
            .sort((a, b) => new Date(a.split('/').reverse().join('-')) - new Date(b.split('/').reverse().join('-')))
            .map((date) => {
              const entries = groupedData[date];
              const dateTotals = calculateTotals(entries);

              return (
                <React.Fragment key={date}>
                  {entries.map((entry) => {
                    const nbBags = parseInt(entry.nbBags) || 0;
                    const onbBags = parseInt(entry.onbBags) || 0;
                    const ssBags = parseInt(entry.ssBags) || 0;
                    const totalBags = nbBags + onbBags + ssBags;
                    const tonsKgs = parseFloat(entry.tonsKgs) || 0;

                    return (
                      <tr key={entry.id}>
                        <td>{rowIndex++}</td>
                        <td>{date}</td>
                        <td>{entry.godown}</td>
                        <td>{entry.issueMemoId}</td>
                        <td>{entry.grade}</td>
                        {/* A Grade Columns */}
                        <td>{entry.grade === 'RPA' ? formatInteger(totalBags) : ''}</td>
                        <td>{entry.grade === 'RPA' ? formatNumber(tonsKgs) : ''}</td>
                        {/* C Grade Columns */}
                        <td>{entry.grade === 'RPC' ? formatInteger(totalBags) : ''}</td>
                        <td>{entry.grade === 'RPC' ? formatNumber(tonsKgs) : ''}</td>
                        {/* Gunny Types */}
                        <td>{formatInteger(nbBags)}</td>
                        <td>{formatInteger(onbBags)}</td>
                        <td>{formatInteger(ssBags)}</td>
                      </tr>
                    );
                  })}
                  {/* Totals Row for this date */}
                  <tr>
                    <td colSpan="5"><strong>Date Total</strong></td>
                    <td><strong>{formatInteger(dateTotals.totalBagsA)}</strong></td>
                    <td><strong>{formatNumber(dateTotals.totalWeightsA)}</strong></td>
                    <td><strong>{formatInteger(dateTotals.totalBagsC)}</strong></td>
                    <td><strong>{formatNumber(dateTotals.totalWeightsC)}</strong></td>
                    <td><strong>{formatInteger(dateTotals.nbBags)}</strong></td>
                    <td><strong>{formatInteger(dateTotals.onbBags)}</strong></td>
                    <td><strong>{formatInteger(dateTotals.ssBags)}</strong></td>
                  </tr>
                </React.Fragment>
              );
            })}
          {/* Overall Totals Row */}
          <tr>
            <td colSpan="5"><strong>Totals</strong></td>
            <td><strong>{formatInteger(totals.totalBagsA)}</strong></td>
            <td><strong>{formatNumber(totals.totalWeightsA)}</strong></td>
            <td><strong>{formatInteger(totals.totalBagsC)}</strong></td>
            <td><strong>{formatNumber(totals.totalWeightsC)}</strong></td>
            <td><strong>{formatInteger(totals.nbBags)}</strong></td>
            <td><strong>{formatInteger(totals.onbBags)}</strong></td>
            <td><strong>{formatInteger(totals.ssBags)}</strong></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default PrintablePaddy;
