import React, { useMemo } from 'react';
import { useTable } from 'react-table';
import '../styles/Table.css';

const RiceView = ({ data, handleDelete, formatDate, formatNumber, gradeFilter, setGradeFilter }) => {
  // Sort data by adDate and then calculate cumulative tonsKgs for each row
  const cumulativeData = useMemo(() => {
    // Sort data by adDate in ascending order
    const sortedData = [...data].sort((a, b) => new Date(a.adDate) - new Date(b.adDate));

    let cumulativeTons = 0;
    return sortedData.map(row => {
      cumulativeTons += parseFloat(row.tonsKgs) || 0;  // Increment the cumulative total
      return {
        ...row,
        cumulativeTonsKgs: cumulativeTons  // Add cumulativeTonsKgs to the row
      };
    });
  }, [data]);

  const columns = useMemo(() => [
    { Header: 'Date', accessor: 'date', Cell: ({ value }) => formatDate(value) },
    { Header: 'Godown', accessor: 'godown' },
    { Header: 'Challan No', accessor: 'challanNo' },
    { Header: 'Lorry No', accessor: 'lorryNo' },
    { Header: 'Variety', accessor: 'variety' },
    { Header: 'ONB Bags', accessor: 'onbBags', Cell: ({ value }) => parseInt(value) || 0 },
    { Header: 'SS Bags', accessor: 'ssBags', Cell: ({ value }) => parseInt(value) || 0 },
    { Header: 'SWP Bags', accessor: 'swpBags', Cell: ({ value }) => parseInt(value) || 0 },
    { Header: 'Tons/Kgs', accessor: 'tonsKgs', Cell: ({ value }) => formatNumber(value) },
    { Header: 'Cumulative Tons/Kgs', accessor: 'cumulativeTonsKgs', Cell: ({ value }) => formatNumber(value) }, // New column for cumulative tonsKgs
    { Header: 'Moisture %', accessor: 'moisture', Cell: ({ value }) => formatNumber(value) },
    { Header: 'AD No', accessor: 'adNumber' },
    { Header: 'AD Date', accessor: 'adDate', Cell: ({ value }) => formatDate(value) },
    { Header: 'FRK', accessor: 'frk', Cell: ({ value }) => formatNumber(value) },
    {
      Header: 'Actions',
      accessor: 'id',
      Cell: ({ value }) => (
        <button onClick={() => handleDelete(value)}>Delete</button>
      ),
    },
  ], [handleDelete, formatDate, formatNumber]);

  const tableInstance = useTable({ columns, data: cumulativeData });

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow
  } = tableInstance;

  return (
    <div>
      {/* Grade Filter Buttons */}
      <div className="grade-buttons" style={{ marginTop: '10px' }}>
        
        <button
          onClick={() => setGradeFilter('bra')}
          style={{ marginRight: '5px', backgroundColor: gradeFilter === 'bra' ? '#4CAF50' : '#f0f0f0' }}
        >
          Grade A (bra)
        </button>
        
        <button
          onClick={() => setGradeFilter('brc')}
          style={{ marginRight: '5px', backgroundColor: gradeFilter === 'brc' ? '#4CAF50' : '#f0f0f0' }}
        >
          Grade C (brc)
        </button>
        <button
          onClick={() => setGradeFilter(null)}
          style={{ backgroundColor: gradeFilter === null ? '#4CAF50' : '#f0f0f0' }}
        >
          All Grades
        </button>

        
      </div>

      {/* Data Table */}
      <table {...getTableProps()} className="styled-table" style={{ marginTop: '20px' }}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()} key={headerGroup.id}>
              {headerGroup.headers.map(column => (
                <th key={column.id} {...column.getHeaderProps()}>{column.render('Header')}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.length > 0 ? rows.map(row => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()} key={row.id}>
                {row.cells.map(cell => (
                  <td key={cell.column.id} {...cell.getCellProps()}>{cell.render('Cell')}</td>
                ))}
              </tr>
            );
          }) : (
            <tr>
              <td colSpan={columns.length} style={{ textAlign: 'center', padding: '10px' }}>
                No data available.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default RiceView;
