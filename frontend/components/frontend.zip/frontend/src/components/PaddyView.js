// src/components/PaddyView.js

import React from 'react';
import { useTable } from 'react-table';
import '../styles/Table.css';

const PaddyView = ({ data, handleDelete, formatDate, formatNumber, fromMonth, toMonth, setFromMonth, setToMonth }) => {
  const columns = React.useMemo(() => [
    { Header: 'Date', accessor: 'date', Cell: ({ value }) => formatDate(value) },
    { Header: 'Godown', accessor: 'godown' },
    { Header: 'Issue Memo No.', accessor: 'issueMemoId' },
    { Header: 'Variety', accessor: 'grade' },
    { Header: 'Moisture %', accessor: 'moisture', Cell: ({ value }) => formatNumber(value) },
    {
      Header: 'Total Bags',
      accessor: 'totalBags',
      Cell: ({ row }) => {
        const onbBags = parseInt(row.original.onbBags) || 0;
        const ssBags = parseInt(row.original.ssBags) || 0;
        const swpBags = parseInt(row.original.swpBags) || 0;
        const nbBags = parseInt(row.original.nbBags) || 0;
        return onbBags + ssBags + swpBags + nbBags;
      },
    },
    { Header: 'Kgs/Gms', accessor: 'tonsKgs', Cell: ({ value }) => formatNumber(value) },
    { Header: 'Bags (NB)', accessor: 'nbBags' },
    { Header: 'Bags (ONB)', accessor: 'onbBags' },
    { Header: 'Bags (SS)', accessor: 'ssBags' },
    { Header: 'Bags (SWP)', accessor: 'swpBags' },
    { Header: 'Lorry No', accessor: 'lorryNo' },
    {
      Header: 'Progressive Total Bags',
      accessor: 'progTotalBags',
      Cell: ({ row }) => {
        let cumulativeBags = 0;
        for (let i = 0; i <= row.index; i++) {
          const entry = data[i];
          const onbBags = parseInt(entry.onbBags) || 0;
          const ssBags = parseInt(entry.ssBags) || 0;
          const swpBags = parseInt(entry.swpBags) || 0;
          const nbBags = parseInt(entry.nbBags) || 0;
          cumulativeBags += onbBags + ssBags + swpBags + nbBags;
        }
        return cumulativeBags;
      },
    },
    {
      Header: 'Progressive Kgs/Gms',
      accessor: 'progKgsGms',
      Cell: ({ row }) => {
        let cumulativeKgs = 0;
        for (let i = 0; i <= row.index; i++) {
          const entry = data[i];
          cumulativeKgs += parseFloat(entry.tonsKgs) || 0;
        }
        return formatNumber(cumulativeKgs);
      },
    },
    {
      Header: 'Actions',
      accessor: 'id',
      Cell: ({ value }) => (
        <button onClick={() => handleDelete(value)}>Delete</button>
      ),
    },
  ], [handleDelete, formatDate, formatNumber, data]);

  const sortedData = React.useMemo(() => {
    return [...data].sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [data]);

  const tableInstance = useTable({ columns, data: sortedData });

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow
  } = tableInstance;

  return (
    <div>
      {/* Date Filter */}

      {/* Data Table */}
      <table {...getTableProps()} className="styled-table" style={{ marginTop: '20px' }}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()} key={headerGroup.id}>
              {headerGroup.headers.map(column => (
                <th key={column.id} {...column.getHeaderProps()}>{column.render('Header')}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.length > 0 ? rows.map(row => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()} key={row.id}>
                {row.cells.map(cell => (
                  <td key={cell.column.id} {...cell.getCellProps()}>{cell.render('Cell')}</td>
                ))}
              </tr>
            );
          }) : (
            <tr>
              <td colSpan={columns.length} style={{ textAlign: 'center', padding: '10px' }}>
                No data available.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default PaddyView;
