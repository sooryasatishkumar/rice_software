// components/CombinedView.jsx

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../styles/Table.css';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import ReactDOMServer from 'react-dom/server';
import './CombinedView.css'; 
import FrkView from './FrkView';
import RiceView from './RiceView';
import PaddyView from './PaddyView';
import GunnyView from './GunnyView';
import PrintablePaddy from './PrintablePaddy';
import PrintableRice from './PrintableRice';
import PrintableGodownReport from './PrintableGodownReport';
import { openPrintWindow } from '../utils/printUtils'; // Import the reusable print function

const CombinedView = ({ company, year }) => {
  const [view, setView] = useState('rice'); // Default view set to Rice
  const [data, setData] = useState([]);
  const [gradeFilter, setGradeFilter] = useState(null);
  const [fromDate, setFromDate] = useState(''); // Added fromDate state
  const [toDate, setToDate] = useState('');     // Added toDate state
  const [paddyData, setPaddyData] = useState([]);
  const [riceData, setRiceData] = useState([]);
  const [frkTransactions, setFrkTransactions] = useState([]);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Utility Functions
  const formatDate = useCallback((dateString) => {
    const date = new Date(dateString);
    if (isNaN(date)) return 'Invalid Date';
    const options = { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'Asia/Kolkata' };
    return new Intl.DateTimeFormat('en-GB', options).format(date);
  }, []);

  const formatNumber = useCallback((value) => {
    return value !== null && value !== undefined ? parseFloat(value).toFixed(3) : '0.000';
  }, []);


  // Fetch data based on view, company, and year
  useEffect(() => {
    if (!company || !year) {
      console.error('Company and year are required to fetch data.');
      setErrorMsg('Company and Year are required to fetch data.');
      return;
    }

    const fetchData = async () => {
      setLoading(true);
      setErrorMsg('');
      try {
        const params = { company, year };
        if (fromDate) params.fromDate = fromDate;
        if (toDate) params.toDate = toDate;

        if (view === 'gunny') {
          // Fetch both Paddy and Rice data for Gunny view
          const [paddyResponse, riceResponse] = await Promise.all([
            axios.get(`http://localhost:5000/api/paddy`, { params }),
            axios.get(`http://localhost:5000/api/rice`, { params })
          ]);
          setPaddyData(paddyResponse.data);
          setRiceData(riceResponse.data);
        } else if (view === 'frk') {
          // Fetch FRK Transactions for FRK view
          const frkTransactionsResponse = await axios.get(`http://localhost:5000/api/frk/transactions`, { params });
          setFrkTransactions(frkTransactionsResponse.data);
        } else {
          // Fetch data for other views (rice, paddy)
          const apiUrl = `http://localhost:5000/api/${view}`;
          const response = await axios.get(apiUrl, { params });
          setData(response.data);
        }
      } catch (error) {
        // Handle error appropriately
        console.error('Error fetching data:', error);
        setErrorMsg('Failed to fetch data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [view, company, year, fromDate, toDate]);

  // Handle Escape key press to navigate back
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        navigate(-1);
      }
    };

    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [navigate]);

  const handleDelete1 = useCallback((id) => {
    if (window.confirm('Are you sure you want to delete this entry?')) {
      // Set up the delete URL based on the current view (rice or paddy)
      let deleteUrl;
      if (view === 'rice') {
        deleteUrl = `http://localhost:5000/api/rice/${id}`;
      } else if (view === 'paddy') {
        deleteUrl = `http://localhost:5000/api/paddy/${id}`;
      } else {
        return; // If neither rice nor paddy view, exit early
      }
  
      // Parameters to be sent along with the delete request
      const params = { company, year };
  
      axios.delete(deleteUrl, { params })
        .then(() => {
          alert(`${view.charAt(0).toUpperCase() + view.slice(1)} entry deleted successfully!`);
          
          // Update state for rice or paddy data based on the current view
          if (view === 'rice') {
            setRiceData(prevRice => prevRice.filter(entry => entry.id !== id));
          } else if (view === 'paddy') {
            setPaddyData(prevPaddy => prevPaddy.filter(entry => entry.id !== id));
          }
        })
        .catch(error => {
          console.error(`There was an error deleting the ${view} entry!`, error);
          alert(`Failed to delete the ${view} entry. Please try again.`);
        });
    }
  }, [view, company, year, setRiceData, setPaddyData]);
  


  // Handle Delete
  const handleDelete = useCallback((id, type = 'addition') => {
    if (window.confirm('Are you sure you want to delete this entry?')) {
      // Prepare the delete URL and parameters
      const deleteUrl = `http://localhost:5000/api/frk/${id}`;
      const params = { company, year, type };

      axios.delete(deleteUrl, { params })
        .then(() => {
          alert(`${type.charAt(0).toUpperCase() + type.slice(1)} entry deleted successfully!`);
          if (view === 'gunny') {
            // For Gunny view, remove from both paddyData and riceData if applicable
            setPaddyData(prevPaddy => prevPaddy.filter(entry => entry.id !== id));
            setRiceData(prevRice => prevRice.filter(entry => entry.id !== id));
          } else if (view === 'frk') {
            if (type === 'addition') {
              // Remove from FRK Transactions (Additions)
              setFrkTransactions(prevFrk => prevFrk.filter(entry => !(entry.id === id && entry.type === 'addition')));
            } else if (type === 'debit') {
              // Remove from FRK Transactions (Debits)
              setFrkTransactions(prevFrk => prevFrk.filter(entry => !(entry.id === id && entry.type === 'debit')));
            }
          } else {
            setData(prevData => prevData.filter(entry => entry.id !== id));
          }
        })
        .catch(error => {
          console.error(`There was an error deleting the ${type} entry!`, error);
          alert(`Failed to delete the ${type} entry. Please try again.`);
        });
    }
  }, [view, company, year]);

  // Helper function to group data by month and calculate totals
  const groupDataByMonth = useCallback((dataArray) => {
    const grouped = {};

    dataArray.forEach(entry => {
      const date = new Date(entry.date);
      if (isNaN(date)) return; // Skip invalid dates
      const monthKey = `${date.getFullYear()}-${date.getMonth() + 1}`; // e.g., "2024-9"

      if (!grouped[monthKey]) {
        grouped[monthKey] = {
          month: formatDate(entry.date),
          nbBags: 0,
          onbBags: 0,
          ssBags: 0,
          swpBags: 0,
          totalBags: 0,
          tonsKgs: 0
        };
      }

      grouped[monthKey].nbBags += parseInt(entry.nbBags) || 0;
      grouped[monthKey].onbBags += parseInt(entry.onbBags) || 0;
      grouped[monthKey].ssBags += parseInt(entry.ssBags) || 0;
      grouped[monthKey].swpBags += parseInt(entry.swpBags) || 0;
      grouped[monthKey].totalBags += (parseInt(entry.nbBags) || 0) + (parseInt(entry.onbBags) || 0) + (parseInt(entry.ssBags) || 0) + (parseInt(entry.swpBags) || 0);
      grouped[monthKey].tonsKgs += parseFloat(entry.tonsKgs) || 0;
    });

    // Convert the grouped object into an array
    const groupedArray = Object.keys(grouped).map(key => ({
      ...grouped[key],
      tonsKgs: formatNumber(grouped[key].tonsKgs)
    }));

    // Sort by month ascending
    groupedArray.sort((a, b) => new Date(a.month) - new Date(b.month));

    return groupedArray;
  }, [formatDate, formatNumber]);

  // Filter data based on gradeFilter, memoize to prevent unnecessary recalculations
  const filteredData = useMemo(() => {
    if (view === 'gunny') {
      return [];
    }

    const targetData = view === 'frk' ? frkTransactions : data;
    const result = gradeFilter
      ? targetData.filter(entry => entry.variety && entry.variety.trim().toLowerCase() === gradeFilter.toLowerCase())
      : targetData;
    return result;
  }, [data, gradeFilter, frkTransactions, view]);

  const groupDataByGodownAndMonth = useCallback((dataArray, viewType) => {
    const grouped = {};

    dataArray.forEach(entry => {
      const date = new Date(entry.date);
      if (isNaN(date)) return; // Skip invalid dates
      const month = date.toLocaleString('default', { month: 'long', year: 'numeric' });

      if (!grouped[month]) {
        grouped[month] = [];
      }

      // Calculate weight
      let weight = parseFloat(entry.tonsKgs) || 0;

      if (viewType === 'rice') {
        // Include FRK for rice entries
        const frk = parseFloat(entry.frk) || 0;
        weight += frk;
      }

      let gradeA = 0;
      let gradeC = 0;
      let paddyUP = 0;

      if (viewType === 'paddy') {
        // For paddy, assign weight to gradeA or gradeC based on entry.grade
        if (entry.grade === 'RPA') {
          gradeA = weight;
        } else if (entry.grade === 'RPC') {
          gradeC = weight;
        }
      } else if (viewType === 'rice') {
        if (entry.variety === 'BRA') {
          gradeA = weight;
        } else if (entry.variety === 'BRC') {
          gradeC = weight;
        }
      }

      // Define 'godown' from entry, with fallback
      const godown = entry.godown || 'Unknown';

      grouped[month].push({
        godown,
        paddyUP,
        gradeA,
        gradeC,
        total: paddyUP + gradeA + gradeC,
      });
    });

    // Combine entries with the same godown in the same month
    const monthsArray = Object.keys(grouped).map((month) => {
      const entries = grouped[month];

      // Combine entries by godown
      const godownMap = {};

      entries.forEach((entry) => {
        if (!godownMap[entry.godown]) {
          godownMap[entry.godown] = {
            godown: entry.godown,
            paddyUP: 0,
            gradeA: 0,
            gradeC: 0,
            total: 0,
          };
        }
        godownMap[entry.godown].paddyUP += entry.paddyUP;
        godownMap[entry.godown].gradeA += entry.gradeA;
        godownMap[entry.godown].gradeC += entry.gradeC;
        godownMap[entry.godown].total += entry.total;
      });

      // Convert godownMap to an array
      const godownsArray = Object.values(godownMap);

      // Sort godowns by name
      godownsArray.sort((a, b) => a.godown.localeCompare(b.godown));

      return {
        month,
        godowns: godownsArray,
      };
    });

    // Sort months by date
    monthsArray.sort((a, b) => new Date(a.month) - new Date(b.month));

    return monthsArray;
  }, []);

  // Export to Excel
  const exportToExcel = useCallback(() => {
    if (view === 'gunny') {
      if (paddyData.length === 0 && riceData.length === 0) {
        alert('No Gunny data available to export.');
        return;
      }

      // Group and prepare Paddy and Rice data
      const groupedPaddy = groupDataByMonth(paddyData);
      const groupedRice = groupDataByMonth(riceData);

      const workbook = XLSX.utils.book_new();

      // Add Paddy Sheet
      if (groupedPaddy.length > 0) {
        const paddyWorksheet = XLSX.utils.json_to_sheet(groupedPaddy);
        XLSX.utils.book_append_sheet(workbook, paddyWorksheet, 'Paddy Data');
      }

      // Add Rice Sheet
      if (groupedRice.length > 0) {
        const riceWorksheet = XLSX.utils.json_to_sheet(groupedRice);
        XLSX.utils.book_append_sheet(workbook, riceWorksheet, 'Rice Data');
      }

      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const dataBlob = new Blob([excelBuffer], { type: 'application/octet-stream' });
      saveAs(dataBlob, `gunny_data.xlsx`);

      alert('Gunny data exported successfully!');
    } else if (view === 'frk') {
      if (frkTransactions.length === 0) {
        alert('No FRK data available to export.');
        return;
      }

      // Separate additions and debits
      const additions = frkTransactions.filter(tx => tx.type === 'addition');
      const debits = frkTransactions.filter(tx => tx.type === 'debit');

      const workbook = XLSX.utils.book_new();

      // Add Additions Sheet
      if (additions.length > 0) {
        const additionsSheet = XLSX.utils.json_to_sheet(additions.map(tx => ({
          ID: tx.id,
          Date: tx.date,
          'FRK Added (KGs)': tx.frkAdded,
          Type: tx.type
        })));
        XLSX.utils.book_append_sheet(workbook, additionsSheet, 'FRK Additions');
      }

      // Add Debits Sheet
      if (debits.length > 0) {
        const debitsSheet = XLSX.utils.json_to_sheet(debits.map(tx => ({
          ID: tx.id,
          Date: tx.date,
          'FRK Debited (KGs)': tx.frkDebited,
          Type: tx.type
        })));
        XLSX.utils.book_append_sheet(workbook, debitsSheet, 'FRK Debits');
      }

      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const dataBlob = new Blob([excelBuffer], { type: 'application/octet-stream' });
      saveAs(dataBlob, `frk_data.xlsx`);

      alert('FRK data exported successfully!');
    } else {
      if (filteredData.length === 0) {
        alert('No data available to export.');
        return;
      }
      const worksheet = XLSX.utils.json_to_sheet(filteredData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, `${view.charAt(0).toUpperCase() + view.slice(1)} Data`);
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const dataBlob = new Blob([excelBuffer], { type: 'application/octet-stream' });
      saveAs(dataBlob, `${view}_data.xlsx`);
    }
  }, [filteredData, view, paddyData, riceData, groupDataByMonth, frkTransactions]);

  // Print functionality
  const handlePrint = useCallback(() => {
    if (view === 'paddy') {
      printPaddyData();
    } else if (view === 'rice') {
      printRiceData();
    } else if (view === 'frk') {
      printFrkData();
    } else if (view === 'gunny') {
      printGunnyData();
    } else {
      window.print();
    }
  }, [view, filteredData, gradeFilter, paddyData, riceData, frkTransactions]);

  // Print functions
  const printPaddyData = useCallback(() => {
    const printableContent = ReactDOMServer.renderToString(
      <PrintablePaddy data={filteredData} />
    );
    openPrintWindow('Paddy Entries', printableContent);
  }, [filteredData, openPrintWindow]);

  const printRiceData = useCallback(() => {
    const printableContent = ReactDOMServer.renderToString(
      <PrintableRice
        data={filteredData}
        gradeFilter={gradeFilter}
        printBill={false} // Adjust as needed
      />
    );
    openPrintWindow('Rice Entries', printableContent);
  }, [filteredData, gradeFilter, openPrintWindow]);

  const printFrkData = useCallback(() => {
    const printableContent = ReactDOMServer.renderToString(
      <FrkView
        frkTransactions={frkTransactions}
        handleDelete={() => {}} // Disable delete in print
        formatDate={formatDate}
        formatNumber={formatNumber}
        isPrintable={true} // A flag to indicate printable mode
      />
    );
    openPrintWindow('FRK Stock Summary', printableContent);
  }, [frkTransactions, formatDate, formatNumber, openPrintWindow]);

  const printGunnyData = useCallback(() => {
    // 1. Helper function to format "dd/mm/yyyy" to "Month Year" (e.g., "July 2024")
    const formatMonthYear = (dateString) => {
      if (!dateString) return '';

      const [day, month, year] = dateString.split('/').map(Number);
      if (
        !day || !month || !year ||
        day < 1 || day > 31 ||
        month < 1 || month > 12 ||
        year < 1000 || year > 9999
      ) {
        return 'Invalid Date';
      }

      const date = new Date(year, month - 1, day);
      if (isNaN(date.getTime())) {
        return 'Invalid Date';
      }

      return date.toLocaleString('default', { month: 'long', year: 'numeric' });
    };

    // 2. Helper function to sort grouped data by month and year
    const sortGroupedData = (groupedData) => {
      return [...groupedData].sort((a, b) => {
        const [aDay, aMonth, aYear] = a.month.split('/').map(Number);
        const [bDay, bMonth, bYear] = b.month.split('/').map(Number);
        if (aYear !== bYear) {
          return aYear - bYear;
        }
        return aMonth - bMonth;
      });
    };

    // 3. Group and sort data by month
    const groupedPaddy = groupDataByMonth(paddyData);
    const groupedRice = groupDataByMonth(riceData);
    const sortedGroupedPaddy = sortGroupedData(groupedPaddy);
    const sortedGroupedRice = sortGroupedData(groupedRice);

    // 4. Calculate Totals for Paddy
    const paddyTotals = {
      nbBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.nbBags, 0),
      onbBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.onbBags, 0),
      ssBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.ssBags, 0),
      swpBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.swpBags, 0),
      totalBags: sortedGroupedPaddy.reduce((sum, entry) => sum + entry.totalBags, 0),
      tonsKgs: sortedGroupedPaddy.reduce((sum, entry) => sum + parseFloat(entry.tonsKgs), 0).toFixed(3)
    };

    // 5. Calculate Totals for Rice
    const riceTotals = {
      nbBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.nbBags, 0),
      onbBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.onbBags, 0),
      ssBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.ssBags, 0),
      swpBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.swpBags, 0),
      totalBags: sortedGroupedRice.reduce((sum, entry) => sum + entry.totalBags, 0),
      tonsKgs: sortedGroupedRice.reduce((sum, entry) => sum + parseFloat(entry.tonsKgs), 0).toFixed(3)
    };

    // 6. Shifted Paddy Issue Gunny (each category moved one position)
    const shiftedPaddyIssue = {
      nbBags: 0, // NB shifted to ONB
      onbBags: paddyTotals.nbBags, // NB shifted to ONB
      ssBags: paddyTotals.onbBags, // ONB shifted to SS
      swpBags: paddyTotals.ssBags, // SS shifted to SWP
      totalBags: 0 + paddyTotals.nbBags + paddyTotals.onbBags + paddyTotals.ssBags // NB is 0
    };

    // 7. Excess = Rice Deposits Gunny - Paddy Issue Gunny
    const excess = {
      nbBags: riceTotals.nbBags - paddyTotals.nbBags,
      onbBags: riceTotals.onbBags - paddyTotals.onbBags,
      ssBags: riceTotals.ssBags - paddyTotals.ssBags,
      swpBags: riceTotals.swpBags - paddyTotals.swpBags,
      totalBags: (riceTotals.nbBags - paddyTotals.nbBags) +
                 (riceTotals.onbBags - paddyTotals.onbBags) +
                 (riceTotals.ssBags - paddyTotals.ssBags) +
                 (riceTotals.swpBags - paddyTotals.swpBags)
    };

    // 8. Balance Gunny to be Deposited = Shifted Paddy Issue Gunny - Rice Deposits Gunny
    const balanceToBeDeposited = {
      nbBags: shiftedPaddyIssue.nbBags - riceTotals.nbBags,
      onbBags: shiftedPaddyIssue.onbBags - riceTotals.onbBags,
      ssBags: shiftedPaddyIssue.ssBags - riceTotals.ssBags,
      swpBags: shiftedPaddyIssue.swpBags - riceTotals.swpBags,
      totalBags: (shiftedPaddyIssue.nbBags - riceTotals.nbBags) +
                 (shiftedPaddyIssue.onbBags - riceTotals.onbBags) +
                 (shiftedPaddyIssue.ssBags - riceTotals.ssBags) +
                 (shiftedPaddyIssue.swpBags - riceTotals.swpBags)
    };


    // Create Printable Content
    const printableContent = ReactDOMServer.renderToString(
      <div>
        {/* Paddy Gunny Receipt */}
        <h3>Paddy Gunny Receipt</h3>
        <table className="styled-table">
          <thead>
            <tr>
              <th>Month</th>
              <th>NB</th>
              <th>ONB</th>
              <th>SS</th>
              <th>SWP</th>
              <th>Total Bags</th>
            </tr>
          </thead>
          <tbody>
            {sortedGroupedPaddy.map((entry, index) => (
              <tr key={index}>
                <td>{formatMonthYear(entry.month)}</td>
                <td>{entry.nbBags}</td>
                <td>{entry.onbBags}</td>
                <td>{entry.ssBags}</td>
                <td>{entry.swpBags}</td>
                <td>{entry.totalBags}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Rice Gunny Deposit */}
        <h3>Rice Gunny Deposit</h3>
        <table className="styled-table">
          <thead>
            <tr>
              <th>Month</th>
              <th>NB</th>
              <th>ONB</th>
              <th>SS</th>
              <th>SWP</th>
              <th>Total Bags</th>
            </tr>
          </thead>
          <tbody>
            {sortedGroupedRice.map((entry, index) => (
              <tr key={index}>
                <td>{formatMonthYear(entry.month)}</td>
                <td>{entry.nbBags}</td>
                <td>{entry.onbBags}</td>
                <td>{entry.ssBags}</td>
                <td>{entry.swpBags}</td>
                <td>{entry.totalBags}</td>
              </tr>
            ))}
            {/* Grand Totals for Rice */}
          </tbody>
        </table>

        {/* Due Gunny Accounts */}
        <h3>Due Gunny Accounts</h3>
        <table className="styled-table">
          <thead>
            <tr>
              <th>Description</th>
              <th>NB</th>
              <th>ONB</th>
              <th>SS</th>
              <th>SWP</th>
              <th>Total Bags</th>
            </tr>
          </thead>
          <tbody>
            {/* Paddy Issue Gunny */}
            <tr>
              <td>Paddy Issue Gunny</td>
              <td>{paddyTotals.nbBags}</td>
              <td>{paddyTotals.onbBags}</td>
              <td>{paddyTotals.ssBags}</td>
              <td>{paddyTotals.swpBags}</td>
              <td>{paddyTotals.totalBags}</td>
            </tr>
            {/* Shifted Paddy Issue Gunny */}
            <tr>
              <td>Paddy Issue Gunny Shifted</td>
              <td>{shiftedPaddyIssue.nbBags}</td>
              <td>{shiftedPaddyIssue.onbBags}</td>
              <td>{shiftedPaddyIssue.ssBags}</td>
              <td>{shiftedPaddyIssue.swpBags}</td>
              <td>{shiftedPaddyIssue.totalBags}</td>
            </tr>
            {/* Rice Deposits Gunny */}
            <tr>
              <td>Rice Deposits Gunny</td>
              <td>{riceTotals.nbBags}</td>
              <td>{riceTotals.onbBags}</td>
              <td>{riceTotals.ssBags}</td>
              <td>{riceTotals.swpBags}</td>
              <td>{riceTotals.totalBags}</td>
            </tr>
            {/* Excess */}
            <tr>
              <td>Excess</td>
              <td>{excess.nbBags}</td>
              <td>{excess.onbBags}</td>
              <td>{excess.ssBags}</td>
              <td>{excess.swpBags}</td>
              <td>{excess.totalBags}</td>
            </tr>
            {/* Balance Gunny to be Deposited */}
            <tr>
              <td>Balance Gunny to be Deposited</td>
              <td>{balanceToBeDeposited.nbBags}</td>
              <td>{balanceToBeDeposited.onbBags}</td>
              <td>{balanceToBeDeposited.ssBags}</td>
              <td>{balanceToBeDeposited.swpBags}</td>
              <td>{balanceToBeDeposited.totalBags}</td>
            </tr>
          </tbody>
        </table>

        {/* Grand Totals */}
      </div>
    );

    // Open Print Window with the Printable Content
    openPrintWindow('Gunny Receipt Summary', printableContent);
  }, [paddyData, riceData, groupDataByMonth, openPrintWindow]);

  const handlePrintGodownWise = useCallback(() => {
    const viewType = view; // 'rice' or 'paddy'
    const godownWiseData = groupDataByGodownAndMonth(filteredData, viewType);
    const printableContent = ReactDOMServer.renderToString(
      <PrintableGodownReport data={godownWiseData} viewType={viewType} />
    );
    openPrintWindow(`${viewType === 'paddy' ? 'Paddy' : 'Rice'} Godown-wise Report`, printableContent);
  }, [view, filteredData, groupDataByGodownAndMonth, openPrintWindow]);

  const handlePrintBill = useCallback(() => {
    // Render PrintableRice with extra columns and monthly totals
    const printableContent = ReactDOMServer.renderToString(
      <PrintableRice
        data={filteredData}
        gradeFilter={gradeFilter}
        printBill={true} // Indicate we are printing the bill version
      />
    );
    openPrintWindow('Rice Entries - Bill', printableContent);
  }, [filteredData, gradeFilter, openPrintWindow]);

  const groupDataByGodown = useCallback((dataArray, viewType) => {
    const grouped = {};
  
    dataArray.forEach(entry => {
      const date = new Date(entry.date);
      if (isNaN(date)) return; // Skip invalid dates
      const month = date.toLocaleString('default', { month: 'long', year: 'numeric' });
  
      if (!grouped[month]) {
        grouped[month] = [];
      }
  
      // Calculate weight
      let weight = parseFloat(entry.tonsKgs) || 0;
  
      if (viewType === 'rice') {
        // Include FRK for rice entries
        const frk = parseFloat(entry.frk) || 0;
        weight += frk;
      }
  
      let gradeA = 0;
      let gradeC = 0;
      let paddyUP = 0;
  
      if (viewType === 'paddy') {
        // For paddy, assign weight to gradeA or gradeC based on entry.grade
        if (entry.grade === 'RPA') {
          gradeA = weight;
        } else if (entry.grade === 'RPC') {
          gradeC = weight;
        }
      } else if (viewType === 'rice') {
        if (entry.variety === 'BRA') {
          gradeA = weight;
        } else if (entry.variety === 'BRC') {
          gradeC = weight;
        }
      }
  
      // Define 'godown' from entry, with fallback
      const godown = entry.godown || 'Unknown';
  
      grouped[month].push({
        godown,
        paddyUP,
        gradeA,
        gradeC,
        total: paddyUP + gradeA + gradeC,
      });
    });
  
    // Combine entries with the same godown in the same month
    const monthsArray = Object.keys(grouped).map((month) => {
      const entries = grouped[month];
  
      // Combine entries by godown
      const godownMap = {};
  
      entries.forEach((entry) => {
        if (!godownMap[entry.godown]) {
          godownMap[entry.godown] = {
            godown: entry.godown,
            paddyUP: 0,
            gradeA: 0,
            gradeC: 0,
            total: 0,
          };
        }
        godownMap[entry.godown].paddyUP += entry.paddyUP;
        godownMap[entry.godown].gradeA += entry.gradeA;
        godownMap[entry.godown].gradeC += entry.gradeC;
        godownMap[entry.godown].total += entry.total;
      });
  
      // Convert godownMap to an array
      const godownsArray = Object.values(godownMap);
  
      // Sort godowns by name
      godownsArray.sort((a, b) => a.godown.localeCompare(b.godown));
  
      return {
        month,
        godowns: godownsArray,
      };
    });
  
    // Sort months by date
    monthsArray.sort((a, b) => new Date(a.month) - new Date(b.month));
  
    return monthsArray;
  }, []);

  const handlePrintByGodown = useCallback(() => {
    const viewType = view; // 'rice' or 'paddy'
    const godownWiseData = groupDataByGodownAndMonth(filteredData, viewType);
    const printableContent = ReactDOMServer.renderToString(
      <PrintableGodownReport data={godownWiseData} viewType={viewType} />
    );
    openPrintWindow(`${viewType === 'paddy' ? 'Paddy' : 'Rice'} Godown-wise Report`, printableContent);
  }, [view, filteredData, groupDataByGodownAndMonth, openPrintWindow]);

  return (
    <div className="table-container">
      <h2>Select Data View</h2>
      <select
        value={view}
        onChange={(e) => {
          setView(e.target.value);
          setGradeFilter(null); // Reset grade filter when view changes
          setErrorMsg(''); // Reset error messages
        }}
      >
        <option value="rice">Rice Entries</option>
        <option value="paddy">Paddy Entries</option>
        <option value="frk">FRK Entries</option>
        <option value="gunny">Gunny Receipt</option>
      </select>

      {/* Date Pickers */}
      <div style={{ marginTop: '20px' }}>
        <label>
          From Date:
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            style={{ marginLeft: '10px' }}
          />
        </label>
        <label style={{ marginLeft: '20px' }}>
          To Date:
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            style={{ marginLeft: '10px' }}
          />
        </label>
      </div>

      {/* Export and Print Buttons */}
      <div style={{ marginTop: '20px' }}>
        <button onClick={exportToExcel} className="no-print">Export to Excel</button>
        <button onClick={handlePrint} style={{ marginLeft: '10px' }} className="no-print">Print</button>

        {/* Conditionally render the Print Bill button in Rice view */}
        {view === 'rice' && (
          <button onClick={handlePrintBill} style={{ marginLeft: '10px' }} className="no-print">
            Print Bill
          </button>
        )}

        {(view === 'rice' || view === 'paddy') && (
          <button onClick={handlePrintByGodown} style={{ marginLeft: '10px' }} className="no-print">
            Print by Godown
          </button>
        )}
      </div>

      {errorMsg && <p style={{ color: 'red', marginTop: '10px' }}>{errorMsg}</p>}
      {loading ? (
        <p style={{ marginTop: '20px' }}>Loading data...</p>
      ) : (
        <>
          {view === 'frk' && (
            <FrkView
              frkTransactions={frkTransactions}
              handleDelete={handleDelete}
              formatDate={formatDate}
              formatNumber={formatNumber}
              company={company}
              year={year}
              fromDate={fromDate}
              toDate={toDate}
            />
          )}
          {view === 'rice' && (
            <RiceView
              data={filteredData}
              handleDelete={handleDelete1}
              formatDate={formatDate}
              formatNumber={formatNumber}
              gradeFilter={gradeFilter}
              setGradeFilter={setGradeFilter}
              fromDate={fromDate}
              toDate={toDate}
            />
          )}
          {view === 'paddy' && (
            <PaddyView
              data={filteredData}
              handleDelete={handleDelete1}
              formatDate={formatDate}
              formatNumber={formatNumber}
              fromDate={fromDate}
              toDate={toDate}
            />
          )}
          {view === 'gunny' && (
            <GunnyView
              paddyData={paddyData}
              riceData={riceData}
              groupDataByMonth={groupDataByMonth}
            />
          )}
        </>
      )}
    </div>
  );
};

export default CombinedView;
