import React, { useState, useEffect } from 'react';
import axios from 'axios';

const FrkView = ({ company, year }) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFrkData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/frk/frk-balance', {
          params: { company, year }
        });
        setData(response.data);
      } catch (error) {
        console.error('Error fetching FRK data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFrkData();
  }, [company, year]);

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this FRK entry?')) {
      try {
        await axios.delete(`http://localhost:5000/api/frk/${id}`);
        alert('FRK entry deleted successfully.');
        // After deleting, remove the entry from the data state
        setData((prevData) => prevData.filter((entry) => entry.id !== id));
      } catch (error) {
        console.error('Error deleting FRK entry:', error);
        alert('Failed to delete FRK entry. Please try again.');
      }
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      <h2>FRK Balance and Rice Usage</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>FRK Added (Tons/Kgs)</th>
            <th>FRK Used (Tons/Kgs)</th>
            <th>Balance (Tons/Kgs)</th>
            <th>Actions</th> {/* Add Actions column */}
          </tr>
        </thead>
        <tbody>
          {data.map((entry, index) => (
            <tr key={index}>
              <td>{entry.date}</td>
              <td>{entry.frkAdded}</td>
              <td>{entry.frkUsed}</td>
              <td>{entry.balance}</td>
              <td>
                {entry.frkAdded > 0 && (
                  <button onClick={() => handleDelete(entry.id)}>
                    Delete
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default FrkView;
