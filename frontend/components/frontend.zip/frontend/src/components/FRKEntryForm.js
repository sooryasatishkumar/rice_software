import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../styles/Form.css';

const FRKEntryForm = ({ company, year }) => {
  const [formData, setFormData] = useState({
    date: '',
    frk: '',         // Use 'frk' to match backend field
    company: company, // Automatically set from props
    year: year        // Automatically set from props
  });

  const [error, setError] = useState(null);  // Error state
  const [loading, setLoading] = useState(false);  // Loading state

  const navigate = useNavigate();

  useEffect(() => {
    // Handle Escape key to navigate back
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        navigate(-1);  // Navigate back
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [navigate]);

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: name === 'frk' ? (value === '' ? '' : Number(value)) : value  // Convert FRK to number
    });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);  // Reset error
    setLoading(true);  // Set loading

    // Prepare data to submit
    const dataToSubmit = {
      date: formData.date,
      company: formData.company,
      year: formData.year,
      frk: formData.frk === '' ? null : formData.frk  // Handle empty input
    };

    try {
      // Send POST request to backend
      const response = await axios.post('http://localhost:5000/api/frk', dataToSubmit);
      alert('FRK details entered successfully!');
      
      // Reset form data after successful submission
      setFormData({
        date: '',
        frk: '',
        company: company,
        year: year
      });
    } catch (error) {
      console.error('There was an error submitting the form!', error);
      if (error.response && error.response.data && error.response.data.error) {
        setError(error.response.data.error);  // Display backend error
      } else {
        setError('Failed to submit FRK details. Please try again.');  // Generic error message
      }
    } finally {
      setLoading(false);  // End loading
    }
  };

  return (
    <div className="form-container">
      <h2>FRK Entry Form</h2>
      {error && <div className="error-message">{error}</div>}  {/* Display error message */}
      <form onSubmit={handleSubmit}>
        <label htmlFor="date">Date:</label>
        <input 
          type="date" 
          name="date" 
          id="date"
          value={formData.date} 
          onChange={handleChange} 
          required 
        />

        <label htmlFor="frk">FRK Quantity (KGs):</label>
        <input 
          type="number" 
          name="frk" 
          id="frk"
          value={formData.frk} 
          onChange={handleChange} 
          required 
          min="0"
          step="0.01"
        />

        {/* Hidden fields for company and year */}
        <input type="hidden" name="company" value={formData.company} />
        <input type="hidden" name="year" value={formData.year} />

        <button type="submit" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit'}
        </button>
      </form>
    </div>
  );
};

export default FRKEntryForm;
