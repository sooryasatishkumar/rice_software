import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Form.css';

const CompanyYearSelection = ({ setCompany, setYear }) => {
  const [selectedCompany, setSelectedCompany] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [selectedYear, setSelectedYear] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const company = newCompany || selectedCompany;
    setCompany(company);
    setYear(selectedYear);
    navigate('/home');
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit}>
        <label>Select Company:</label>
        <select onChange={(e) => setSelectedCompany(e.target.value)} required disabled={!!newCompany}>
          <option value="">Select a company</option>
          <option value="Anandhakrishnan">Anandhakrishnan Agro</option>
        </select>

        <label>Select Year:</label>
        <select onChange={(e) => setSelectedYear(e.target.value)} required>
          <option value="">Select a year</option>
          <option value="2024">2024-2025</option>
          <option value="02024">KMS 2024-2025</option>
          <option value="2025">2025-2026</option>
          <option value="02025">KMS 2025-2026</option>
          <option value="2026">2026-2027</option>
          <option value="02026">KMS 2026-2027</option>
        </select>

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default CompanyYearSelection;
