export const openPrintWindow = (title, content, printBill) => {
  const printWindow = window.open('', '_blank', 'width=1200,height=800');
  if (!printWindow) {
    alert('Failed to open print window. Please disable your popup blocker and try again.');
    return;
  }

  // Additional styles to force rendering of borders and adjust QC No column
  const combinedStyles = `
    /* Enforce table borders for printing */
    table, th, td {
      border: 1px solid black !important;
      border-collapse: collapse;
      padding: 4px;
    }

    /* Force color adjustments for printing */
    body {
      -webkit-print-color-adjust: exact;
      font-family: Arial, sans-serif;
      font-size: 12px;
    }

    /* Specific styles for QC No column when printBill is true */
  `;

  printWindow.document.write(`
    <html>
      <head>
        <title>${title}</title>
        <style>
          ${combinedStyles}
        </style>
      </head>
      <body>
        ${content}
        <script>
          window.onload = function() {
            window.focus();
            window.print();
            window.close();
          }
        </script>
      </body>
    </html>
  `);

  printWindow.document.close();
};
