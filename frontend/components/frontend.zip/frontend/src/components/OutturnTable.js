import React, { useState, useEffect, useCallback, useMemo } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../styles/Table.css';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import ReactDOMServer from 'react-dom/server';

const OutturnRegister = ({ company, year }) => {
  const [selectedOption, setSelectedOption] = useState('total');
  const [outturnData, setOutturnData] = useState([]);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [filteredData, setFilteredData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50; // Adjust as needed
  const navigate = useNavigate();

  // Determine if the current view is belated
  const isBelated = selectedOption.includes('belated');

  // Fetch outturn data based on selected option
  const fetchOutturnData = useCallback(() => {
    if (!company || !year) {
      console.error('Company and year are required!');
      return;
    }

    let url;
    // Determine the URL to use based on the selected option
    switch (selectedOption) {
      case 'a':
        url = `http://localhost:5000/api/outturn/a?company=${company}&year=${year}`;
        break;
      case 'c':
        url = `http://localhost:5000/api/outturn/c?company=${company}&year=${year}`;
        break;
      case 'a-belated':
        url = `http://localhost:5000/api/outturn/a-belated?company=${company}&year=${year}`;
        break;
      case 'c-belated':
        url = `http://localhost:5000/api/outturn/c-belated?company=${company}&year=${year}`;
        break;
      case 'belated-a-combined':
        url = `http://localhost:5000/api/outturn/belated-a-combined?company=${company}&year=${year}`;
        break;
      case 'belated-c-combined':
        url = `http://localhost:5000/api/outturn/belated-c-combined?company=${company}&year=${year}`;
        break;
      default:
        url = `http://localhost:5000/api/outturn/?company=${company}&year=${year}`;
    }

    axios.get(url)
      .then(response => {
        console.log('Fetched data:', response.data);
        setOutturnData(response.data);
        setCurrentPage(1); // Reset to first page on new data fetch
      })
      .catch(error => {
        console.error('There was an error fetching the outturn data!', error);
      });
  }, [selectedOption, company, year]);

  useEffect(() => {
    fetchOutturnData();
  }, [fetchOutturnData]);

  // Apply date filters whenever outturnData, fromDate, or toDate changes
  useEffect(() => {
    const applyDateFilters = () => {
      if (!fromDate && !toDate) {
        setFilteredData(outturnData);
        return;
      }

      const filtered = outturnData.filter(row => {
        // Determine which date to use based on whether it's belated or not
        const dateString = isBelated ? row.paddy_date || row.rice_date : row.date;
        if (!dateString) return false;

        const rowDate = new Date(dateString);
        if (isNaN(rowDate)) return false;

        const from = fromDate ? new Date(fromDate) : null;
        const to = toDate ? new Date(toDate) : null;

        if (from && rowDate < from) return false;
        if (to && rowDate > to) return false;

        return true;
      });

      setFilteredData(filtered);
      setCurrentPage(1); // Reset to first page on filter change
    };

    applyDateFilters();
  }, [outturnData, fromDate, toDate, isBelated]);

  // Handle Escape key press to navigate back
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        navigate(-1);
      }
    };

    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [navigate]);

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleFromDateChange = (e) => {
    setFromDate(e.target.value);
  };

  const handleToDateChange = (e) => {
    setToDate(e.target.value);
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date)) return 'Invalid Date';
    const options = { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'Asia/Kolkata' };
    return new Intl.DateTimeFormat('en-GB', options).format(date);
  };

  const formatNumber = (value) => {
    return value !== null && value !== undefined ? parseFloat(value).toFixed(3) : '0.000';
  };

  const calculateDeadline = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date)) return 'Invalid Date';
    date.setDate(date.getDate() + 15);
    return formatDate(date.toISOString());
  };

  const calculateDaysExtended = (dueDateString, depositedDateString) => {
    if (!dueDateString || !depositedDateString) return '';
    const dueDate = new Date(dueDateString);
    const depositedDate = new Date(depositedDateString);
    if (isNaN(dueDate) || isNaN(depositedDate)) return 'Invalid Date';
    
    // Calculate the deadline based on the due date
    const deadline = new Date(dueDate);
    deadline.setDate(deadline.getDate() + 15);
    
    const diffTime = depositedDate - deadline;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : '';
  };

  // Optional: Add validation to prevent setting fromDate after toDate
  useEffect(() => {
    if (fromDate && toDate && new Date(fromDate) > new Date(toDate)) {
      alert('"From Date" cannot be later than "To Date".');
      setFromDate('');
      setToDate('');
    }
  }, [fromDate, toDate]);

  // Pagination logic
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    return filteredData.slice(start, end);
  }, [filteredData, currentPage]);

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

  // Export to Excel function
  const exportToExcel = () => {
    if (filteredData.length === 0) {
      alert('No data available to export.');
      return;
    }

    const worksheetData = filteredData.map((row, index) => {
      if (isBelated) {
        return {
          'S.No': row.s_no || index + 1,
          'Date': formatDate(row.paddy_date || row.rice_date),
          'Paddy Variety': row.variety || '',
          'Paddy Bags': row.paddy_bags || '',
          'Paddy Tons Kgs': formatNumber(row.paddy_weight || 0),
          'Rice Due Tons Kgs': formatNumber(row.rice_due || 0),
          'Rice Date': formatDate(row.rice_date),
          'Rice Deposited Tons Kgs': formatNumber(row.rice_deposited || 0),
          'Ad No': row.rice_ad_no || '',
          'Due Date': calculateDeadline(row.paddy_date),
          'Belated Days': calculateDaysExtended(row.paddy_date, row.rice_date)
        };
      } else {
        return {
          'Date': formatDate(row.date),
          'Paddy Variety': row.paddy_variety || '',
          'Paddy Bags': row.paddy_bags || '',
          'Paddy Tons Kgs': formatNumber(row.paddy_tonsKgs),
          'Progressive Paddy Bags': row.progPaddyBags || '',
          'Progressive Paddy Tons Kgs': formatNumber(row.progPaddyTonsKgs),
          'Rice Due Tons Kgs': formatNumber(row.rice_due_rpa || row.rice_due_rpc),
          'Progressive Rice Due Tons Kgs': formatNumber(row.progRiceDueTotal || row.progRiceDueRPA || row.progRiceDueRPC),
          'Rice Variety': row.rice_variety || '',
          'Ad No': row.ad_no || '',
          'Rice Ad Bags': row.rice_bags || '',
          'Rice Ad Tons Kgs': formatNumber(row.rice_tonsKgs),
          'Progressive Rice Bags': formatNumber(row.progRiceBagsTotal || row.progRiceBagsBRA || row.progRiceBagsBRC),
          'Progressive Rice Tons Kgs': formatNumber(row.progRiceTonsKgsTotal || row.progRiceTonsKgsBRA || row.progRiceTonsKgsBRC),
          'Total Balance Rice Due': formatNumber(row.totalBalanceRiceDue),
        };
      }
    });

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Outturn Register');

    const excelBuffer = XLSX.write(workbook, { type: 'array', bookType: 'xlsx' });
    const data = new Blob([excelBuffer], { type: 'application/octet-stream' });

    saveAs(data, `OutturnRegister_${selectedOption}_${Date.now()}.xlsx`);
  };

  // Print function
  const handlePrint = () => {
    if (filteredData.length === 0) {
      alert('No data available to print.');
      return;
    }
  
    const printableContent = ReactDOMServer.renderToString(
      <div>
        <h2 style={{ textAlign: 'center' }}>Outturn Register - {selectedOption.toUpperCase()}</h2>
        <table>
  <thead>
    {isBelated ? (
      <tr>
        <th>S.No</th>
        <th>Paddy Date</th> 
        <th>Paddy Variety</th>
        <th>Paddy Bags</th>
        <th>Paddy Tons Kgs</th>
        <th>Rice Due Tons Kgs</th>
        <th>Rice Date</th>
        <th>Rice Deposited</th>
        <th>Rice Ad No</th>
        <th>Due Date</th>
        <th>Belated Days</th>
      </tr>
    ) : (
      <tr>
        <th>Paddy Date</th> 
        <th>Paddy Variety</th>
        <th>Paddy Bags</th>
        <th>Paddy Tons Kgs</th>
        <th>Progressive Paddy Bags</th>
        <th>Progressive Paddy Tons Kgs</th>
        <th>Rice Due Tons Kgs</th>
        <th>Progressive Rice Due Tons Kgs</th>
        <th>Rice Variety</th>
        <th>Ad No</th>
        <th>Rice Ad Bags</th>
        <th>Rice Ad Tons Kgs</th>
        <th>Progressive Rice Bags</th>
        <th>Progressive Rice Tons Kgs</th>
        <th>Total Balance Rice Due</th>
      </tr>
    )}
  </thead>
  <tbody>
    {(() => {
      let lastPaddyDate = null; 
      let serialCounter = 1; // Ensures continuous serial numbers

      return filteredData.map((row, index) => {
        let currentPaddyDate = row.paddy_date || lastPaddyDate;
        let isInherited = !row.paddy_date && lastPaddyDate;

        if (row.paddy_date) {
          lastPaddyDate = row.paddy_date; 
        }

        return (
          <tr key={index} className={row.rowType === 'total' ? 'total-row' : ''}>
            {isBelated ? (
              <>
                <td>{serialCounter++}</td> {/* Auto-incremented serial number */}
                <td>{isInherited ? '' : formatDate(currentPaddyDate)}</td>
                <td>{row.variety || ''}</td>
                <td>{row.paddy_bags || ''}</td>
                <td>{formatNumber(row.paddy_weight || 0)}</td>
                <td>{formatNumber(row.rice_due || 0)}</td>
                <td>{formatDate(row.rice_date)}</td>
                <td>{formatNumber(row.rice_deposited || 0)}</td>
                <td>{row.rice_ad_no || ''}</td>
                <td>{calculateDeadline(currentPaddyDate)}</td>
                <td>{calculateDaysExtended(currentPaddyDate, row.rice_date)}</td>
              </>
            ) : (
              <>
                <td>{serialCounter++}</td> {/* Auto-incremented serial number */}
                <td>{isInherited ? '' : formatDate(currentPaddyDate)}</td>
                <td>{row.paddy_variety || ''}</td>
                <td>{row.paddy_bags || ''}</td>
                <td>{formatNumber(row.paddy_tonsKgs)}</td>
                <td>{row.progPaddyBags || ''}</td>
                <td>{formatNumber(row.progPaddyTonsKgs)}</td>
                <td>{formatNumber(row.rice_due_rpa || row.rice_due_rpc)}</td>
                <td>{formatNumber(row.progRiceDueTotal || row.progRiceDueRPA || row.progRiceDueRPC)}</td>
                <td>{row.rice_variety || ''}</td>
                <td>{row.ad_no || ''}</td>
                <td>{row.rice_bags || ''}</td>
                <td>{formatNumber(row.rice_tonsKgs)}</td>
                <td>{formatNumber(row.progRiceBagsTotal || row.progRiceBagsBRA || row.progRiceBagsBRC)}</td>
                <td>{formatNumber(row.progRiceTonsKgsTotal || row.progRiceTonsKgsBRA || row.progRiceTonsKgsBRC)}</td>
                <td>{formatNumber(row.totalBalanceRiceDue)}</td>
              </>
            )}
          </tr>
        );
      });
    })()}
  </tbody>
</table>


      </div>
    );
  
    const printWindow = window.open('', '_blank');
    printWindow.document.open();
    printWindow.document.write(`
      <html>
        <head>
          <title>Outturn Register - ${selectedOption.toUpperCase()}</title>
          <style>
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #000;
              padding: 8px;
              text-align: center;
              font-size: 12px;
            }
            th {
              background-color: #f2f2f2;
            }
            h2 {
              text-align: center;
            }
            .total-row {
              font-weight: bold;
              background-color: #e0e0e0;
            }
            @media print {
              @page {
                size: portrait; /* Set to portrait */
                margin: 20mm;
              }
              body {
                -webkit-print-color-adjust: exact;
              }
            }
          </style>
        </head>
        <body>
          ${printableContent}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };
  
  return (
    <div className="table-container">
      <h2>Outturn Register</h2>
      
      {/* Date Filters */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <div>
          <label htmlFor="fromDate">From Date:</label>
          <input
            type="date"
            id="fromDate"
            value={fromDate}
            onChange={handleFromDateChange}
            max={toDate || ''}
          />
        </div>
        <div>
          <label htmlFor="toDate">To Date:</label>
          <input
            type="date"
            id="toDate"
            value={toDate}
            onChange={handleToDateChange}
            min={fromDate || ''}
          />
        </div>
      </div>

      {/* Outturn Type Selection */}
      <div style={{ marginBottom: '20px' }}>
        <label htmlFor="outturnSelect">Select Outturn Type:</label>
        <select id="outturnSelect" value={selectedOption} onChange={handleOptionChange}>
          <option value="total">Total Outturn</option>
          <option value="a">Outturn for A</option>
          <option value="c">Outturn for C</option>
          <option value="a-belated">A-Grade Belated Rice Accounts</option>
          <option value="c-belated">C-Grade Belated Rice Accounts</option>
          <option value="belated-a-combined">A-Grade Combined Belated Rice Accounts</option>
          <option value="belated-c-combined">C-Grade Combined Belated Rice Accounts</option>
        </select>
      </div>

      {/* Export and Print Buttons */}
      <div style={{ marginBottom: '20px' }}>
  {/* <button onClick={exportToExcel}>Export to Excel</button> */}       
   <button onClick={handlePrint} style={{ marginLeft: '10px' }}>Print</button>
      </div>

      {/* Outturn Data Table */}
      <table>
        <thead>
          {isBelated ? (
            <>
              <tr>
                <th rowSpan="2">S.No</th>
                <th rowSpan="2">Date</th>
                <th rowSpan="2">Paddy Variety</th>
                <th rowSpan="2">Paddy Bags</th>
                <th rowSpan="2">Paddy Tons Kgs</th>
                <th rowSpan="2">Rice Due Tons Kgs</th>
                <th colSpan="3">Rice Deposited</th>
                <th rowSpan="2">Due Date</th>
                <th rowSpan="2">Belated Days</th>
              </tr>
              <tr>
                <th>Date</th>
                <th>Tons Kgs</th>
                <th>Ad No</th>
              </tr>
            </>
          ) : (
            <tr>
              <th>Date</th>
              <th>Paddy Variety</th>
              <th>Paddy Bags</th>
              <th>Paddy Tons Kgs</th>
              <th>Progressive Paddy Bags</th>
              <th>Progressive Paddy Tons Kgs</th>
              <th>Rice Due Tons Kgs</th>
              <th>Progressive Rice Due Tons Kgs</th>
              <th>Rice Variety</th>
              <th>Ad No</th>
              <th>Rice Ad Bags</th>
              <th>Rice Ad Tons Kgs</th>
              <th>Progressive Rice Bags</th>
              <th>Progressive Rice Tons Kgs</th>
              <th>Total Balance Rice Due</th>
            </tr>
          )}
        </thead>
        <tbody>
  {paginatedData.length === 0 ? (
    <tr>
      <td colSpan={isBelated ? 11 : 15}>No data available</td>
    </tr>
  ) : (
    paginatedData.reduce((acc, row, index) => {
      let displayDate = row.paddy_date ? formatDate(row.paddy_date) : ''; // Hide inherited date

      // Update last valid paddy_date internally
      if (row.paddy_date) {
        acc.lastPaddyDate = row.paddy_date;
      }

      acc.elements.push(
        <tr key={index} className={row.rowType === 'total' ? 'total-row' : ''}>
          {isBelated ? (
            <>
              <td>{row.s_no || ''}</td>
              <td>{displayDate}</td> {/* Hide calculated date */}
              <td>{row.variety || ''}</td>
              <td>{row.paddy_bags || ''}</td>
              <td>{formatNumber(row.paddy_weight || 0)}</td>
              <td>{formatNumber(row.rice_due || 0)}</td>
              <td>{formatDate(row.rice_date)}</td>
              <td>{formatNumber(row.rice_deposited || 0)}</td>
              <td>{row.rice_ad_no || ''}</td>
              <td>{calculateDeadline(acc.lastPaddyDate)}</td>
              <td>{calculateDaysExtended(acc.lastPaddyDate, row.rice_date)}</td>
            </>
          ) : (
            <>
              <td>{formatDate(row.date)}</td>
              <td>{row.paddy_variety || ''}</td>
              <td>{row.paddy_bags || ''}</td>
              <td>{formatNumber(row.paddy_tonsKgs)}</td>
              <td>{row.progPaddyBags || ''}</td>
              <td>{formatNumber(row.progPaddyTonsKgs)}</td>
              <td>{formatNumber(row.rice_due_rpa || row.rice_due_rpc)}</td>
              <td>{formatNumber(row.progRiceDueTotal || row.progRiceDueRPA || row.progRiceDueRPC)}</td>
              <td>{row.rice_variety || ''}</td>
              <td>{row.ad_no || ''}</td>
              <td>{row.rice_bags || ''}</td>
              <td>{formatNumber(row.rice_tonsKgs)}</td>
              <td>{formatNumber(row.progRiceBagsTotal || row.progRiceBagsBRA || row.progRiceBagsBRC)}</td>
              <td>{formatNumber(row.progRiceTonsKgsTotal || row.progRiceTonsKgsBRA || row.progRiceTonsKgsBRC)}</td>
              <td>{formatNumber(row.totalBalanceRiceDue)}</td>
            </>
          )}
        </tr>
      );

      return acc;
    }, { lastPaddyDate: null, elements: [] }).elements
  )}
</tbody>
      </table>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'center', gap: '10px' }}>
          <button onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))} disabled={currentPage === 1}>
            Previous
          </button>
          <span>Page {currentPage} of {totalPages}</span>
          <button onClick={() => setCurrentPage(prev => (currentPage < totalPages ? prev + 1 : prev))} disabled={currentPage === totalPages}>
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default OutturnRegister;
